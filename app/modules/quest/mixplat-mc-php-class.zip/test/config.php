<?php

	/**
	 * @version 2.0 13.10.2014
	 */

	// ID проекта в настройках проекта личного кабинета (пример: 2524)
	$serviceId	= "";

	// Ключ API, задаётся в настройках личного кабинета https://client.mixplat.ru/ (пример: 01d563cbfd378f264b253656c48a86476d0faf9e)
	$secretKey	= "";

	// Флаг тестового режима
	$isTestMode	= false;

	// Директория для логов
	$logDirectory = './log/';